package com.example.barbershop_1;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class pageOne extends AppCompatActivity {
    ArrayList<barber> barberList;
    ListView lstViewOne;
    barberAdapter barberAdapter;
    //TextView tvName,tvInfo,tvPhone,tvStar;



    //String[] barberList = {"barber","barber1","barber2","barber3","barber4"};
    //int[] barberImages = {R.drawable.barber,R.drawable.barber1,R.drawable.barber2,R.drawable.barber3,R.drawable.barber4};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_one);
        lstViewOne = findViewById(R.id.lstViewOne);
        Bitmap barber = BitmapFactory.decodeResource(getResources(),R.drawable.barber);
        Bitmap barber1 = BitmapFactory.decodeResource(getResources(),R.drawable.barber1);
        Bitmap barber2 = BitmapFactory.decodeResource(getResources(),R.drawable.barber2);
        Bitmap barber3 = BitmapFactory.decodeResource(getResources(),R.drawable.barber3);
        Bitmap barber4 = BitmapFactory.decodeResource(getResources(),R.drawable.barber4);
        //int review = Integer.parseInt(tvStar.getText().toString());
        //barber br = new barber(barber,tvName.getText().toString(),tvInfo.getText().toString(),tvPhone.getText().toString(),review);
        //barber br1 = new barber(barber1,tvName.getText().toString(),tvInfo.getText().toString(),tvPhone.getText().toString(),review);

        barberList = new ArrayList<barber>();
        //barberList.add(br);
        //barberList.add(br1);
       // barberAdapter = new barberAdapter(this,0,0,barberList);
        lstViewOne.setAdapter(barberAdapter);

       /* lstViewOne.findViewById(R.id.lstViewOne);
        customBaseAdapetr customBaseAdapetr = new customBaseAdapetr(getApplicationContext(),barberList,barberImages);
        lstViewOne.setAdapter(customBaseAdapetr);*/
    }
}